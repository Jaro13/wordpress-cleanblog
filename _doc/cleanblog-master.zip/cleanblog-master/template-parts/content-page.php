<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Clean Blog
 */

?>

<?php the_content(); ?>

<?php wp_link_pages(); ?>