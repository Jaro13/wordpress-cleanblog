<?php
/**
 * Template part for displaying single posts.
 *
 * @package Clean Blog
 */

?>

<?php the_content(); ?>

<?php wp_link_pages(); ?>